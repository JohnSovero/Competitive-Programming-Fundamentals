#pragma once

#include "Merge.hpp"
using namespace std;
void mergeSort(int* A, int n) {
	if (n > 1) {
		int mitad = n / 2;
		int* A1 = new int[mitad];
		int* A2 = new int[n - mitad];

		for (int i = 0; i < mitad; i++) {
			A1[i] = A[i];
			cout << A[i] << " - ";
		}
		cout << "\n";
		for (int i = mitad; i < n; i++) {
			A2[i - mitad] = A[i];
			cout << A2[i-mitad] << " - ";
		}
		cout << "\n";
		mergeSort(A1, mitad);
		mergeSort(A2, n - mitad);
		Merge(A1, A2, A, n);
	}
}
